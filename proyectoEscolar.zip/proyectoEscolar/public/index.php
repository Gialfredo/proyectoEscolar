<?php


require_once __DIR__ . '/../config/config.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$controller = $_POST['controller'] ?? 'EstudianteController';
$action = $_POST['action'] ?? 'index';

try {
    $conexion = new PDO(DB_DSN, DB_USER, DB_PASSWORD);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Error al conectar con la base de datos: ' . $e->getMessage());
}

switch ($controller) {
    case 'EstudianteController':
        require_once __DIR__ . '/../app/controllers/EstudianteController.php';
        $controllerInstance = new EstudianteController($conexion);
        break;
    default:
        die('Controlador no encontrado.');
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (method_exists($controllerInstance, $action)) {

        $controllerInstance->$action();
    } else {
        die('Acción no encontrada.');
    }
} else {
    $controllerInstance->index();
}
