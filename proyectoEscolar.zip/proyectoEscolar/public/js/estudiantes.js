$(document).ready(function () {
    $('#form-estudiante').on('submit', function (e) {
        e.preventDefault();

        var nombre = $('#nombre_estudiante').val();
        var apellido = $('#apellido_estudiante').val();
        var edad = parseInt($('#edad_estudiante').val());

        $.ajax({
            type: 'POST',
            url: '/proyectoEscolar/public/index.php',
            data: {
                controller: 'EstudianteController',
                action: 'agregar',
                nombre_estudiante: nombre,
                apellido_estudiante: apellido,
                edad_estudiante: edad
            },
            success: function (response) {

                console.log("Respuesta del servidor sin procesar:", response);

                if (response.status === 'success') {
                    // Agregar el nuevo estudiante a la tabla sin recargar la página
                    var nuevoEstudiante = '<tr><td><strong>' + nombre + '</strong></td><td>' + apellido + '</td><td>' + edad + '</td></tr>';
                    $('#lista-estudiantes').append(nuevoEstudiante);


                    $('#nombre_estudiante').val('');
                    $('#apellido_estudiante').val('');
                    $('#edad_estudiante').val('');
                } else {
                    alert('Error al agregar el estudiante');
                }
            },
            error: function () {
                alert('Error al realizar la petición');
            }
        });
    });
});
