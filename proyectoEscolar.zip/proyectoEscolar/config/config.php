<?php


define('DB_HOST', 'localhost');
define('DB_NAME', 'gestion_escolar');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

define('DB_DSN', 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME);

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
