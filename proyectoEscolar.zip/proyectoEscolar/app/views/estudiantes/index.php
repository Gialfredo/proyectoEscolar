<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Estudiantes</title>
    <link rel="stylesheet" href="/proyectoEscolar/public/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="text-center my-4">
            <img src="/proyectoEscolar/public/img/LogoITCA.png" alt="Logo ITCA" width="300">
        </div>
        <h1 class="my-4 text-center">Gestión de estudiantes</h1>

        <div class="card mb-4">
            <div class="card-header text-center">Agregar estudiante</div>
            <div class="card-body">
                <form id="form-estudiante">
                    <div class="form-group">
                        <label for="nombre_estudiante">Nombre:</label>
                        <input type="text" class="form-control" name="nombre_estudiante" id="nombre_estudiante" required>
                    </div>

                    <div class="form-group">
                        <label for="apellido_estudiante">Apellidos:</label>
                        <input type="text" class="form-control" name="apellido_estudiante" id="apellido_estudiante" required>
                    </div>

                    <div class="form-group">
                        <label for="edad_estudiante">Edad:</label>
                        <input type="number" class="form-control" name="edad_estudiante" id="edad_estudiante" required>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">Agregar estudiante</button>
                </form>
            </div>
        </div>

        <h2 class="text-center">Lista de estudiantes</h2>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Apellidos</th>
                        <th>Edad</th>
                    </tr>
                </thead>
                <tbody id="lista-estudiantes">
                    <?php if (!empty($estudiantes)): ?>
                        <?php foreach ($estudiantes as $estudiante): ?>
                            <tr>
                                <td><strong><?= $estudiante['nombre'] ?></strong></td>
                                <td><?= $estudiante['apellido'] ?></td>
                                <td><?= $estudiante['edad'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" class="text-center">No hay estudiantes registrados.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="/proyectoEscolar/public/js/estudiantes.js"></script>
</body>

</html>