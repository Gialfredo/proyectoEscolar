<?php
require_once __DIR__ . '/EstudianteDAOInterface.php';

class EstudianteDAOMySQL implements EstudianteDAOInterface
{
    private $db;

    public function __construct($conexion)
    {
        $this->db = $conexion;
    }

    public function obtenerEstudiantes()
    {
        try {
            $query = $this->db->query("SELECT * FROM estudiantes");
            return $query->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Error al obtener estudiantes: ' . $e->getMessage());
            return [];
        }
    }

    public function agregarEstudiante($nombre, $apellido, $edad)
    {
        try {
            $query = $this->db->prepare(
                "INSERT INTO estudiantes (nombre, apellido, edad) 
                VALUES (:nombre, :apellido, :edad)"
            );
            $query->execute([
                'nombre' => $nombre,
                'apellido' => $apellido,
                'edad' => $edad
            ]);
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            error_log('Error al agregar estudiante: ' . $e->getMessage());
            return false;
        }
    }
}
