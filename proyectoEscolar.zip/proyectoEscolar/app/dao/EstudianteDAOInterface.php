<?php
interface EstudianteDAOInterface
{
    public function obtenerEstudiantes();
    public function agregarEstudiante($nombre, $apellido, $edad);
}
