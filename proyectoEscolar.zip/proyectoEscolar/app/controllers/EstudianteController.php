<?php
class EstudianteController
{
    private $estudianteModel;

    public function __construct($conexion)
    {
        require_once __DIR__ . '/../dao/EstudianteDAOMySQL.php';
        require_once __DIR__ . '/../models/EstudianteModel.php';

        $dao = new EstudianteDAOMySQL($conexion);
        $this->estudianteModel = new EstudianteModel($dao);
    }

    public function index()
    {
        // Obtener los estudiantes desde el modelo
        $estudiantes = $this->estudianteModel->obtenerEstudiantes();
        // Pasar la variable $estudiantes a la vista
        require_once __DIR__ . '/../views/estudiantes/index.php';
    }

    public function agregar()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Limpiar los datos del formulario
            $nombre = htmlspecialchars($_POST['nombre_estudiante']);
            $apellido = htmlspecialchars($_POST['apellido_estudiante']);
            $edad = htmlspecialchars($_POST['edad_estudiante']);

            // Agregar estudiante a la base de datos
            $result = $this->estudianteModel->agregarEstudiante($nombre, $apellido, $edad);

            header('Content-Type: application/json');


            if ($result) {
                echo json_encode(['status' => 'success', 'id' => $result]);
            } else {
                echo json_encode(['status' => 'error']);
            }


            exit();
        }
    }
}
