<?php
class EstudianteModel
{
    private $estudianteDAO;

    public function __construct(EstudianteDAOInterface $estudianteDAO)
    {
        $this->estudianteDAO = $estudianteDAO;
    }

    public function obtenerEstudiantes()
    {
        return $this->estudianteDAO->obtenerEstudiantes();
    }

    public function agregarEstudiante($nombre, $apellido, $edad)
    {
        return $this->estudianteDAO->agregarEstudiante($nombre, $apellido, $edad);
    }
}
