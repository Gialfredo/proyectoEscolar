<?php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../app/controllers/EstudianteController.php';

$controller = new EstudianteController($conexion);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $controller->agregar();
} else {
    $controller->index();
}
